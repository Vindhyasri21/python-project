import pandas as pd
import re
import string
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score

# =========================
# TEXT CLEANING
# =========================
def clean_text(text):
    text = str(text).lower()
    text = re.sub(f"[{string.punctuation}]", "", text)
    text = re.sub(r'\s+', ' ', text)
    return text

# =========================
# LOAD DATA
# =========================
fake = pd.read_csv("Fake.csv")
true = pd.read_csv("True.csv")

print("Fake shape:", fake.shape)
print("True shape:", true.shape)

# =========================
# CHECK COLUMNS
# =========================
print("Columns:", fake.columns)

# 👉 IMPORTANT: adjust if needed
TEXT_COLUMN = "text"

# =========================
# LABELING
# =========================
fake["label"] = 0
true["label"] = 1

data = pd.concat([fake, true])

# =========================
# CLEAN TEXT
# =========================
data[TEXT_COLUMN] = data[TEXT_COLUMN].apply(clean_text)

# =========================
# SHUFFLE
# =========================
data = data.sample(frac=1, random_state=42).reset_index(drop=True)

X = data[TEXT_COLUMN]
y = data["label"]

# =========================
# TF-IDF
# =========================
vectorizer = TfidfVectorizer(stop_words="english", max_df=0.7)
X = vectorizer.fit_transform(X)

# =========================
# TRAIN TEST SPLIT
# =========================
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# =========================
# MODEL
# =========================
model = LogisticRegression(max_iter=1000)
model.fit(X_train, y_train)

# =========================
# EVALUATION
# =========================
y_pred = model.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)

print("\n✅ Model Accuracy:", accuracy)

# =========================
# PREDICTION LOOP
# =========================
print("\n🧠 Fake News Detector Ready (type 'exit' to quit)\n")

while True:
    news = input("Enter news: ")

    if news.lower() == "exit":
        break

    cleaned = clean_text(news)
    vector = vectorizer.transform([cleaned])

    prediction = model.predict(vector)[0]
    confidence = model.predict_proba(vector)[0]

    print("\nPrediction:", prediction)
    print("Confidence [Fake, Real]:", confidence)

    if prediction == 1:
        print("🟢 Real News")
    else:
        print("🔴 Fake News")

    print("\n========================\n")